package kr.or.bit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import javafx.util.converter.PercentageStringConverter;
import kr.or.bit.dto.Board;

//CRUD 함수 > ConnectionPool > 함수단위 연결 ,받환 
public class BoardDao {
	DataSource ds = null;
	
	public BoardDao() throws NamingException {
		Context context = new InitialContext();
		ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
	}
	
	//글쓰기(원본글)
	public int writeok(Board boarddata) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int row = 0;
		try {
			conn = ds.getConnection();
			String sql="insert into jspboard(idx, writer, pwd, subject, content, email, homepage, writedate, readnum,filename,filesize,refer)"+ 
					   " values(jspboard_idx.nextval,?,?,?,?,?,?,sysdate,0,?,0,?)";
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, boarddata.getWriter());
			pstmt.setString(2, boarddata.getPwd());
			pstmt.setString(3, boarddata.getSubject());
			pstmt.setString(4, boarddata.getContent());
			pstmt.setString(5, boarddata.getEmail());
			pstmt.setString(6, boarddata.getHomepage());
			pstmt.setString(7, boarddata.getFilename());
			
			//계층형 게시판
			//refer(참조값) , step , depth
			//1. 원본글 : refer 생성?  , step(0) default , depth(0) default
			//2. 답변글 : refer 생성?  , step +1 , depth +1
			
			int refermax = getMaxRefer();
			int refer = refermax + 1;
			pstmt.setInt(8,refer);
			
			row = pstmt.executeUpdate();
			
		}catch(Exception e) {
			
		}finally {
			try {
				pstmt.close();
				conn.close();//반환하기
			} catch (Exception e2) {
			
			}
		}
		
		
		return row;
	}

	//글쓰기 (refer) 값 생성하기(원본글)
	private int getMaxRefer() {
		Connection conn = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		int refer_max=0;
		try {
			conn = ds.getConnection(); //빌려주세여^^  이따 반납할게요 
			String sql="select nvl(max(refer),0) from jspboard";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				refer_max = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				pstmt.close();
				rs.close();
				conn.close(); // 반납이요 ^^
			}catch (Exception e) {
				
			}
		}
		
		return refer_max;
		
	}
	
	//게시물 목록 보기
	public List<Board>list(int cpage, int pagesize){
		/*
		 페이징 만들기 (왜? 몇백만건 데이터 호출하면 서버 나감,)
		 [1][2][3]....
		 totaldata > 54건 >>pagesize정의
		 pagesize=5
		 규칙> totalpagecount=11(전체 페이지 개수)
		 현재 데이터 100건
		 cpage:1, pagesize:5 > start(시작글번호)1~ end(글번호)6
		 cpage:2, pagesize:5 > start(시작글번호)6~end(글번호)10
		 cpage:11, pagesize:5 > start(시작글번호)51~end(글번호)55
		 
		 
		 
		 */
		
		Connection conn =null;
		PreparedStatement pstmt = null;
		ResultSet rs =null;
		List<Board>list =null;
		try{
			conn = ds.getConnection();
			String sql = "select * from " +
                    "(select rownum rn,idx,writer,email,homepage,pwd,subject , content, writedate, readnum " +
                    ",filename,filesize,refer,depth,step " +
                    " from ( SELECT * FROM jspboard ORDER BY refer DESC , step ASC ) "+
                    " where rownum <= ?" +  //endrow
                ") where rn >= ?"; //startrow
			
			pstmt =conn.prepareStatement(sql);
			//공식같은 로직
			int start = cpage * pagesize - (pagesize -1); //1 * 5 - (5 - 1) >> 1
			int end = cpage * pagesize; // 1 * 5 >> 5
			//
			pstmt.setInt(1, end);
			pstmt.setInt(2, start);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Board>();
			while(rs.next()) {
				Board board = new Board();
				board.setIdx(rs.getInt("idx"));
				board.setSubject(rs.getString("subject"));
				board.setWriter(rs.getString("writer"));
				board.setWritedate(rs.getDate("writedate"));
				board.setReadnum(rs.getInt("readnum"));
				
				//계층형
				board.setRefer(rs.getInt("refer"));
				board.setStep(rs.getInt("step"));
				board.setDepth(rs.getInt("depth"));
				
				list.add(board);
			}
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				pstmt.close();
				rs.close();
				conn.close();//반환
			} catch (Exception e2) {
				
			}
		}
			
		return list;
	}
	
	//게시물 총 건수 구하기
		public int totalBoardCount() {
				Connection conn = null;
				PreparedStatement pstmt = null;
				ResultSet rs = null;
				int totalcount = 0;
				try {
					conn = ds.getConnection(); //dbcp 연결객체 얻기
					String sql="select count(*) cnt from jspboard";
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					if(rs.next()) {
						totalcount = rs.getInt("cnt");
					}
				}catch (Exception e) {
					
				}finally {
					try {
						pstmt.close();
						rs.close();
						conn.close();//반환  connection pool 에 반환하기
					}catch (Exception e) {
						
					}
				}
				return totalcount;
			}
	}






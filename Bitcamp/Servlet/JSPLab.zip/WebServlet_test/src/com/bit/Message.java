package com.bit;

public class Message {
	public String getMessage(String str) {
		return str+"Mode12 base MVC";
	}

}

package com.bit;

import java.io.IOException;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(
		description = "이녀석은 컨트롤러",
		urlPatterns= {
				"/Front.do"
		}		
		)

public class FrontServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public FrontServletController() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cmd = request.getParameter("cmd");
		
		String msg="";
		
		if(cmd.equals("greeting")) { //만약 cmd 문자열이greeting면
			Message m =new Message();//메세지 객체를 생성해라( str 과 Mode12 base MVC를)
			msg = m.getMessage(cmd);
			
		}
		request.setAttribute("msg", msg);
		RequestDispatcher dis =request.getRequestDispatcher("/greeting.jsp");
		dis.forward(request, response);
	}


}

package com;

import java.io.IOException;
import java.util.Date;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/SimpleController")
public class SimpleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public SimpleController() {
    	super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//1.한글처리
		//2.사용자 요청 파악->요청값 받기
		
		//request.getParameter("type")으로 값을 받아서 변수 type에 저장
		String type      = request.getParameter("type"); //type란 파라미터값을 type란 변수에 던진다.
		Object resultobj = null;
		
		//3.요청에 따른 업무 수행(service)
		if(type==null||type.equals("greeting")) { //만약 type가 null 이거나 문자열이 greeting라면
			resultobj="헬로우 월드";                 //resultobj는 헬로우 월드를 출력하라.
		}else if(type.equals("date")) {           //그게 아니라 문자열이 date면
			resultobj=new Date();                 //resultobj는 date객체를 생성해라
		}else{                                   //다 아니면
			resultobj="invalid String type";      //resultobj는 invalid String type를 출력하라
		}
		
		//4.요청 완료에 따른 결과를 저장하기 ->저장방법:request, session, application 객체
	     request.setAttribute("result",resultobj);
	    
	    //5.저장한결과를 클라이언트에게 전달하기(view 지정)
	    //화면에 출력할 페이지 지정-> forward(제어권전달)
	    RequestDispatcher dis = request.getRequestDispatcher("/simpleview.jsp");
	    //RequestDispatcher는 클라이언트로부터 최초에 들어온 요청을 JSP/Servlet 내에서 원하는 자원으로 요청을 넘기는역할을 수행
	    //RequestDispatcher는 특정 자원에 처리를 요청하고 처리 결과를 얻어오는 기능을 수행하는 클래스
	    //즉 dis 변수에 담긴 값을 simpleview.jsp 에게 넘기겠다.
        
	    //6.데이터를 전달
	    dis.forward(request, response);
	    //forward 특정 서블릿 요청을 다른 서블릿이나 jsp에게 넘긴다.
	    ////simpleview.jsp 에게 request 객체의 주소를 전달
	}

	
}

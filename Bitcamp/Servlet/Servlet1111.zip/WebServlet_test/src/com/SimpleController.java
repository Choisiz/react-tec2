package com;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



//@WebServlet("/SimpleController1")
public class SimpleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public SimpleController() {
        super();
        System.out.println("생성자 호출"); //처음  실행할때 실행.

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     System.out.println("클라이언트 요청"); //새로고침 할때마다 생성
     String type =request.getParameter("type");
     Object resultobj=null;
     if(type==null || type.equals("greeting")) {
    	 resultobj="hello world";
     }else if(type.equals("date")) {
    	 resultobj=new Date();
     }else {
    	 resultobj="invalid String type";
     }
     
     request.setAttribute("result", resultobj); //요청완료에 따른 결과를 저장
     
     //저장한 결과 즉 위에 결과를 클라이언트에게 전달한다. 즉 view를 지정 =jsp에게 권한? 주는것?
     //화면에 출력할 페이지 정하고=jsp, 출력할 데이터를 넘기는데 방법은? forward(제어권)
     RequestDispatcher dis = request.getRequestDispatcher("/simpleview.jsp");//출력할 페이지
     dis.forward(request, response);
     //request에게 객체의 주소를 주고, simpleview에게 리퀘스트 주소를 전달한다.
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}

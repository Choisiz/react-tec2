package com.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/FrontBoardController")
public class FrontBoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public FrontBoardController() {
        super();
        
    }
    
    //get, post 두가지 요청에ㅐ 대해서 모두 동작하는 함수
    //1.servelt 제공하는 함수:service()함수
    //2.별도의 함수를 생성해서 개발자마으미doProcess()
    
  private void doProdess(HttpServletRequest request, HttpServletResponse response, String method) throws ServletException, IOException {
		System.out.println("클라이언트요청:"+method);
		//1.한글처리
		
		//2.요청받기:request
		
		//3.요청판단:(판단의 기준:parameter):commod방식
		//  -1:parameter 기준
		//  -2:/board?cmd=login&uerid=kglim&pwd=1004
		//String str = request.getParameter("cmd");
		//if(str.equals("login"){로그인처리}
		
		//board?cmd=boardlist
		//String str = request.getParameter("cmd");
		//if(str.equals("boardlist"){게시판 조회처리}
		
		//tip:url주소로 판단
		//l92.168.0.3:8090/website/board/boardlist
		//l92.168.0.3:8090/website/board/boardwrite?title=aaa&content=hello	
		//마지막 주소값 추철: boardlist(게시판조회처리) or boardwrite(게시판글쓰기처리)
		//이 두가지 말고는 다 비동기 처리
		
		//4.처리결과저장
		
		//5.view 정의
		//view page 생성 : jsp
		//위치-> webContent> board > boardlist.jsp
		//     webContent> error > error.jsp
		//문제점:192.168.0.3:8090/WebServelt_1/board/boardlist.jsp 클라이언트가 이걸 왜워서 들어간다?
		//해결: WEB-INF 보안폴더: view단 페이지를 생성
		//1.WEB-INF > view > board > boardlist.jsp
		//1.WEB-INF > view > error > error.jsp
		
		//6.view에게 전달
		
		/////////////////////////////////////
		
		//1.요청받기(commod)
		//오청주소:192.168.0.3:8090/WebServelt_1/board?cmd=list
		String cmd =request.getParameter("cmd");
		//2.요청판단(업무에 따른 정의)
		String viewpage = null;
		//cmd>null>error.jsp 뷰단으로 처리
		//cmd>boardlist>list.jsp 뷰
		//cmd>boardwrite>write.jsp 뷰
		if(cmd==null) {
			viewpage="/error/error.jsp";
		}else if(cmd.equals("boardlist")) {
			viewpage="/board/boardlist.jsp";
			//DB연결
			//select
			//실행결과(rs)>객체담기
			//boardDao dao = new boardDao();
			//List<board>boardlist=dao.selectBoardList();
			//request.setAttribute('list",boardlist);
			//forward>>view전달>>boardlist.jsp
			//<c:set var="list" values= "<%=request.getAttribute("list")%>">
			//<c:forEach....
		}else if(cmd.equals("boardwrite")) {
			viewpage="/board/boardwrite.jsp";
		}else if(cmd.equals("login")) {
			viewpage="/WEB-INF/login/login.jsp"; //실 개발 코드 보안폴더
		}else {
			viewpage="/error/error.jsp";
		}
		
		//결과
		//가정:List<Emp>list = new ArrayList<>();
		//list.add(new Emp(2000,"김유신");
		//request.setAttribute("emplist",lsit)
		
		//view 지정
		RequestDispatcher dis =request.getRequestDispatcher(viewpage);
		//view forward
		dis.forward(request, response);
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProdess(request, response, "GET");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProdess(request, response, "POST");
	}

}

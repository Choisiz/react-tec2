package com.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebServlet("/FrontBoardController")
public class FrontBoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public FrontBoardController() {
        super();
        
    }
    
    private void doProdess(HttpServletRequest request, HttpServletResponse response, String method) throws ServletException, IOException {
		System.out.println("클라이언트요청:"+method);
		
		String cmd =request.getParameter("cmd");
		String viewpage= null;
		
		if(cmd==null) {                    //만약 cmd가 null이면
			viewpage="/error/error.jsp";   //viewpage는 에러jsp출력
		}else if(cmd.equals("boardlist")) {//cmd문자열이 boardlist면
			viewpage="/board/boardlist.jsp";//viewpage는 boardlist.jsp출력
		}else if(cmd.equals("boardwrite")) {//cmd문자열이 boardwrite면
			viewpage="/board/boardwrite.jsp";//viewpage는 boardwrite.jsp출력
		}else if(cmd.equals("login")) {      //cmd문자열이 로그인이면
			viewpage="/WEB-INF/login/login.jsp"; //viewpage는 로그인jsp출력
		}else {                                 //아무것아니면
			viewpage="/error/error.jsp";        //에러jsp출력
		}
		RequestDispatcher dis =request.getRequestDispatcher(viewpage); //dis를 viewpage에게 넘기자
		//view forward
		dis.forward(request, response);
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}

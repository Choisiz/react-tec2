package kr.or.bit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.or.bit.dto.memo;
import kr.or.bit.utils.Singleton_Helper;

/*
DB작업
CRUD 작업을 하기위한 함수를 생성하는 곳

memo table 에 데이터 에 대해서
전제조회 : select id, email ,content from memo
조건조회 : select id, email ,content from memo where id=?
수정 : update memo set email=? , content=? where id=?
삭제 : delete from memo where id=?
삽입 : insert into memo(id,email,content) values(?,?,?)

default 5개
필요하시면 함수는 추가 .....^^
*/
public class memodao {
	Connection conn = null;
	public memodao() {
		conn = Singleton_Helper.getConnection("oracle");
	}
	
	//1건의 데이터 read (where 조건으로 사용되는 컬럼은 반드시 unique , primary key)
	public memo getMemoListById(String id) {
		/*
		  select id, email ,content from memo where id=?
		  memo m = new memo();
		  m.setId(rs.getInt(1)) ...
		  return m
		*/
		return null;
	}
	
	//전체 데이터 read (where 조건절이 없어요)
	/*public ArrayList<memo> getMemoList()의 역할?*/
	public ArrayList<memo> getMemoList() throws SQLException{
		PreparedStatement pstmt = null;
		//PrepareStatememt 캐시에 객체를 저장
		//반복적으로 사용시 Statement보다 성능이 우수
		//디비를 연결하고 쿼리를 수행할때 사용
		String sql="select id, email , content from memo";
		pstmt = conn.prepareStatement(sql);
		//PrepareStatment는 인자값으로 실행할 sql문을 입력가능
		ResultSet rs = pstmt.executeQuery();
		//ResultSet :DB명령에 대한 반환값 ,select결과를 저장하는 하나의 집합
		//executeQuery: ResultSet을 얻기위한 메소드
		
		/*
		 정리: 디비를 연결하고 쿼리를 수행하기 위해 PreparedStatement 객체를 가져와서 변수 pstmt에 담고 초기에 null값을 선언한다.
		           이후 sql문 (select)문을 작성하여 가지고? 연결하고 싶은 값을 sql을 가져와 변수 sql에 sql문을 담는다.
		          이런 sql문을 가지고 연결하기 위해서 conn(연결).Preparedstatement(디비연결및쿼리수행객체)에 인자값에 sql변수를 담아서
		          초기에 만들어놨던, 디비연결쿼리수행객체가 담긴  pstmt변수에 담는다.
		     pstmt 즉 db연결과 쿼리수행 결과를 저장을 해야한다. 그러긴 위해서는 executeQuery 메소드를 가져와서
		     DB명령에 반환값, 즉 결과를 저장할수 있는 집합을 가진 ResultSet 객체를 가져와 변수 rs에 담는다.
		          즉, rs는 원하는 select 쿼리문과 디비연결 및 그 결과를 저장하는 모든것을 담고있다.      
		 */
		
		
		ArrayList<memo> memolist = new ArrayList<>();
		while(rs.next()) {                           //rs를 돌린다.
			memo m = new memo();                     //arraylist 객체를 지닌 m을 만들어주고
			m.setId(rs.getString("id"));             //속성값 지정(키:rs / 값: id값을 가져옴)
			m.setEmail(rs.getString("email"));       //속성값 지정(키:rs / 값: email값을 가져옴)
			m.setContent(rs.getString("content"));   //속성값 지정(키:rs / 값: content값을 가져옴)
			memolist.add(m);                         //그 m값을 더해준다.
		}
		
		Singleton_Helper.close(rs);                  
		Singleton_Helper.close(pstmt);
		/*굳이 pstmt가 있어야 되나?
		   답변: 값을 담고 있어도 살아있기때문, 각가 별개이기에 닫아줘야한다.*/
	
		return memolist;                              //memolist를 반환해준다.
	}
	
	//Insert
	//Parameter (id,email,cotent)
	//권장: public int insertMemo(memo m){} >> FrameWork 자동화..
	public int insertMemo(String id, String email , String content) {
		int resultrow=0;
		PreparedStatement pstmt = null;
		
		try {
				String sql = "insert into memo(id,email,content) values(?,?,?)";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.setString(2, email);
				pstmt.setString(3, content);
				
				resultrow = pstmt.executeUpdate();
				/*왜 위에는 ResultSet객체를 썻는데 이곳에는 쓰지않고 resultrow사용했을까?
				   답변:ResultSet는 select밖에 안쓴다. 왜냐면 select는 봐야되는데 제공되는 형태로 볼수 있는 객체 
				 * */
				//executeUpdate는 디비에서 추가,삭제,수정 sql문을 실행한다.
				
		}catch(Exception e) {
			System.out.println("Insert : " + e.getMessage());
		}finally {
			Singleton_Helper.close(pstmt);
		}
		return resultrow;
	}
	
	
	
	//------------------------------------없는기능 시작----------------------------------------------------
	//Update
	public int updateMemo(memo m) {
		//update memo set email=? , content=? where id=?
		//m.getId()
		return 0;   //리턴값이 0인이유는 굳이 업데이트문을 쓸일이 없다. 현재 여기서는 insert를 써서 id,email,content를 db에 넣어줘서
	}               //그 데이터를 list를 통해서 클라이언트에게 보여주는 기능밖에없다.
	
	//Delete
	public int deleteMemo(String id) {
		//delete from memo where id=?     //마찬가지로 삭제기능없음
		return 0;
	}
	//------------------------------------없는기능 종료----------------------------------------------------
	
	
	
	//추가함수(id 존재유무판단함수)
	public String isCheckById(String id) {
		//id 존재하면 : "false"
		//존재하지 않으면: "true"
		
		String ismemoid= null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			
				String sql = "select id from memo where id=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id); /*????*/
				
				rs = pstmt.executeQuery();
				
				if(rs.next()) {
					//do {
						//String id = rs.getString("id")
						ismemoid = "false"; //id가 존재
						
					//}while(rs.next());
				}else {
						ismemoid = "true"; //id가 존재하지 않으면
				}
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}finally {
			Singleton_Helper.close(rs);
			Singleton_Helper.close(pstmt);
		}
		//System.out.println("ismemoid : " + ismemoid);
		return ismemoid;    //ismemoid를 반환
	}
}







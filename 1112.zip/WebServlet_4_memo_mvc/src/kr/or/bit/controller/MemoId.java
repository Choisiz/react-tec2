package kr.or.bit.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.bit.dao.memodao;


@WebServlet("/MemoId")
public class MemoId extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public MemoId() {
        super();
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 request.setCharacterEncoding("UTF-8");
		 response.setContentType("text/html;charset=UTF-8"); //클라언트에게 전달한 페이지의 정보 구성
		 PrintWriter out = response.getWriter();
		 
		 String id = request.getParameter("id");
		 System.out.println("id : " + id);
		 memodao dao = new memodao();                   //db값 가져와서 변수 dao에 저장
		 String ischeck = dao.isCheckById(id);          //dao에 있는 isCheckById에 인자에 id를 넣은값을 변수 ischeck에 저장
		 //key point
		 out.print(ischeck);                            //출력해라. ischeck를
		 
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}

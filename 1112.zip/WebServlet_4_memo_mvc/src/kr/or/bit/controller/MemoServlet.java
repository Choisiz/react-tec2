package kr.or.bit.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.bit.dao.memodao;


@WebServlet("/MemoServlet")
public class MemoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;  //주민등록같은 값,인증

    public MemoServlet() {
        super();
      
    }
    private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	  
    	  //요청의 판단 (x) 통으로 >> 이 servlet (insert : /MemoServlet)
    	  //doprocess를 만들어서 doget,dopost든 다 할 수 있게, 파리미터값에 요청과 응답객체가 존재한다.
    	//1.한글지원 	
    	  request.setCharacterEncoding("UTF-8");
    	//2.요청값(id,email,memo)받기
    	  String id = request.getParameter("id");
    	  String email = request.getParameter("email");
    	  String memo = request.getParameter("memo");
    	  //out.print(id + "," + email + "," + memo);
    	//3.한글넘기기
    	  response.setContentType("text/html;charset=UTF-8"); //클라언트에게 전달한 페이지의 정보 구성
    	  PrintWriter out = response.getWriter();
    	 
    	//db값 가져와 요청값을 변수에 담기
    	//insert
    	  try{
    		  	memodao dao = new memodao(); //POINT db객체 가져옴
    		  	int n = dao.insertMemo(id, email, memo); //id,email,memo값을 인자로너어 변수n에 저장
    	   
    	   if(n>0){/*0이 아니라 null아님?*/
    		    out.print("<script>");
    	     	out.print("alert('등록성공..');");
    	     	out.print("location.href='MemoList';"); 
    	     	//주소창에 입력 enter (F5) 요청
    	     	//localhost:8090/WebServlet_3/MemoList
    	    out.print("</script>");
    	   }else{ //insert 에서 현실적으로 경우 ...
    		    out.print("<script>");
    		    out.print("alert('등록실패..');");
    		    out.print("location.href='memo.html';");
    		    out.print("</script>");
    	   }

    	  }catch(Exception e){
    	   out.print("<b> 오류 :" +  e.getMessage()  + "</b>");
    	  }
    	  
	}
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

}
